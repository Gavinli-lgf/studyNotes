^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package lgsvl_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.4 (2020-10-21)
------------------
* Add VehicleOdometry.msg to README
* Adding VehicleOdometry.
* Update README and LICENSE
* Update package description and maintainers
* Add ultrasonic message.
* Contributors: Guodong Rong, Hadi Tabatabaee, Piotr Jaroszek

0.0.3 (2020-05-29)
------------------
* Update readme and license
* Changing some Vector3's to Points where they make more sense.
* Renaming CanBus to CanBusData.
* Adding VehicleStateData.
* Adding VehicleControlData.
* Adding CanBus and DetectedRadarObject/Array.
* Making package hybrid ROS1/ROS2 package.
* Contributors: Hadi Tabatabaee, Joshua Whitley

0.0.2 (2020-03-04)
------------------
* Include signal messages in README
* add messages for ground truth signals
* updated license
* Contributors: David Uhm

0.0.1 (2018-12-18)
------------------
* add changelog
* update initial version number
* add license
* add Ros package for ground truth messages
* initial commit
* Contributors: David Uhm
